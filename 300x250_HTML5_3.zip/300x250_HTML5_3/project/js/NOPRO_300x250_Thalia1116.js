var NOPRO_300x250_Thalia1116 = Project_Base.extend({
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //private var
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //---------------------------------------------------------
	  //Number
	  //---------------------------------------------------------
	  width:undefined,
	  height:undefined,
	  firstLoad:true,
	  //---------------------------------------------------------
	  //---------------------------------------------------------
	  //Boolean
	  //---------------------------------------------------------
	  callStart:true,
	  //---------------------------------------------------------
	  //String
	  //---------------------------------------------------------
	  traceID:undefined,
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //Constructor
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  init:function(obj, init_preStart) {
		  this._super(obj, false);
	  },
	  //------------------------------------------------------------------------------------- 
	  div_CFG:function() {
		  this._super();
	  },
	  //------------------------------------------------------------------------------------- 
	  visibility_CFG:function() {	
		//--------------------------------------
		$elm = this.$div.find(".OnlyMacys_svg.black");
		TweenLite.set($elm, {opacity:1});
	  },
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //Methods
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  step_0:function() {
		//--------------------------------------
		//Init var
		//--------------------------------------
		var delay = .1;
    	var state = 0;
		var dur = dur;
		var $elm;
		//--------------------------------------		
		delay += .2;	
		$elm = this.$div.find(".text_0");
	    TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, y:20, ease:Expo.easeOut});
		//--------------------------------------	
		$elm = this.$div.find(".text_1");
	    TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1, {delay:delay, opacity:0, ease:Expo.easeInOut});	
		//--------------------------------------	
		$elm = this.$div.find(".text_2");
	    TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, y:-20,ease:Expo.easeOut});
		delay += .2;	
	    //--------------------------------------	
		$elm = this.$div.find(".item_0");
	    TweenLite.set($elm, {opacity:1, scale:.5});
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		TweenLite.set($elm, {scale:1.1});
		TweenLite.from($elm, 9, {delay:delay,  scale:1, ease:Quad.easeInOut});	
		// ------- Macy's Logo --------		
		$elm = this.$div.find(".OnlyMacys_svg.black");
		TweenLite.set($elm, {opacity:1});
		
		delay += 0.2;
		$elm = this.$div.find(".OnlyMacys_svg.black #shell");
		TweenLite.set($elm, {opacity:1, scale:.659, x:23, y:215});
		TweenLite.from($elm,1, {delay:delay, opacity:0, ease:Quad.easeOut});
		//--------------------------------------
		delay += 2;
		TweenLite.delayedCall(delay, $.proxy(this.step_1, this));
	  },
	 	//------------------------------------------------------------------------------------- 
		step_1:function() {
	  	//--------------------------------------
		//Remove 1st Frame
		var delay = .1;
		//--------------------------------------	
		$elm = this.$div.find(".item_0");
		TweenLite.to($elm, 2, {delay:delay, opacity:0, ease:Expo.easeInOut});
		//--------------------------------------
		$elm = this.$div.find(".item_1");
	    TweenLite.set($elm, {opacity:1, scale:1});
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------		
		delay += .2;
		$elm = this.$div.find(".text_3");
	    TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Expo.easeInOut});
		//--------------------------------------	
		delay += 0;
		$elm = this.$div.find(".cta");
		TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		},
	  mouseover:function(e) {
	}
});