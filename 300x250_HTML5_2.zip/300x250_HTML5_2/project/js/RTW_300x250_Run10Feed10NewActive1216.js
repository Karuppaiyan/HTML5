var RTW_300x250_Run10Feed10NewActive1216 = Project_Base.extend({
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //private var
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //---------------------------------------------------------
	  //Number
	  //---------------------------------------------------------
	  width:undefined,
	  height:undefined,
	  //firstLoad:true,
	  //---------------------------------------------------------
	  //---------------------------------------------------------
	  //Boolean
	  //---------------------------------------------------------
	  callStart:true,
	  //---------------------------------------------------------
	  //String
	  //---------------------------------------------------------
	  traceID:undefined,
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //Constructor
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  init:function(obj, init_preStart) {
		  this._super(obj, false);
	  },
	  //------------------------------------------------------------------------------------- 
	  div_CFG:function() {
		  this._super();
	  },
	  //------------------------------------------------------------------------------------- 
	  visibility_CFG:function() {	
		//--------------------------------------
		$elm = this.$div.find(".Macys_svg.white #shell");
		TweenLite.set($elm, {opacity:0});		
	  },
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  //Methods
	  ///////////////////////////////////////////////////////////////////////////////////////
	  ///////////////////////////////////////////////////////////////////////////////////////
	  step_0:function() {
		//--------------------------------------
		//Init var
		//--------------------------------------
		var delay = 0;
    	var state = 0;
		var $elm;
		//--------------------------------------
	    $elm = this.$div.find(".item_0");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Expo.easeInOut});
		//-------------------------------------
		TweenLite.set($elm, {scale:1.1});
		TweenLite.from($elm, 9, {delay:delay,  scale:1, ease:Quad.easeInOut});	
		//--------------------------------------
		delay += .2;
		$elm = this.$div.find(".txt_0");
		TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------			
		delay += .1;
	    $elm = this.$div.find(".text_0");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------		
		delay += 2;
		TweenLite.delayedCall(delay, $.proxy(this.step_1, this));
	  },
	 	//------------------------------------------------------------------------------------- 
	  step_1:function() {
	  	//--------------------------------------
	  	var delay = .1;
		//--------------------------------------		
		$elm = this.$div.find(".text_0");
		TweenLite.to($elm, 1, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
		$elm = this.$div.find(".txt_0");
		TweenLite.to($elm, 1, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------	
	    $elm = this.$div.find(".item_0");
		TweenLite.to($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
	    //-------------------------------------
		$elm = this.$div.find(".Macys_svg.black");
		TweenLite.set($elm, {opacity:1});
		//--------------------------------------
		$elm = this.$div.find(".Macys_svg.black #shell");
		TweenLite.set($elm, {opacity:1, scale:.70, x:185,  y:213});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
	    $elm = this.$div.find(".item_1");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Expo.easeInOut});
		//-------------------------------------
		TweenLite.set($elm, {scale:1.1});
		TweenLite.from($elm, 9, {delay:delay,  scale:1, ease:Quad.easeInOut});	
		//--------------------------------------		
		delay += .1;
	    $elm = this.$div.find(".text_1");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		delay += 3;
		TweenLite.delayedCall(delay, $.proxy(this.step_2, this));
	  },
	  //------------------------------------------------------------------------------------- 
	   step_2:function() {
	  	//--------------------------------------
		//Remove 1st Frame
		var delay = .1;
		//--------------------------------------
		$elm = this.$div.find(".Macys_svg.black");
		TweenLite.to($elm, 1, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
		$elm = this.$div.find(".text_1");
		TweenLite.to($elm, 1, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
		$elm = this.$div.find(".item_1");
		TweenLite.to($elm, 1, {delay:delay, opacity:0, ease:Quad.easeInOut});
	    //--------------------------------------
		$elm = this.$div.find(".item_2");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 2.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------				
		delay += .2;
		$elm = this.$div.find(".txt_0");
		TweenLite.set($elm, {opacity:1,  x:"-1"});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------	
		delay += .2;			
	    $elm = this.$div.find(".txt_1");
		TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		delay += .1;
	    $elm = this.$div.find(".text_2");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		delay += .1;
	    $elm = this.$div.find(".text_3");
		TweenLite.set($elm, {opacity:1 });
		TweenLite.from($elm, 2, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//--------------------------------------
		$elm = this.$div.find(".Macys_svg.white");
		TweenLite.set($elm, {opacity:1});
		//--------------------------------------
		$elm = this.$div.find(".Macys_svg.white #shell");
		TweenLite.set($elm, {opacity:1, scale:.70, x:185,  y:213});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
		$elm = this.$div.find(".cta");
		TweenLite.set($elm, {opacity:1});
		TweenLite.from($elm, 1.5, {delay:delay, opacity:0, ease:Quad.easeInOut});
		//-------------------------------------
		},
	 	//-------------------------------------------------------------------------------------
	  mouseover:function(e) {
	}
});