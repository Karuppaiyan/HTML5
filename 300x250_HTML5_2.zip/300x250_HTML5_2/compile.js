{
	"compile" : [
		{
			"save_path" : "",
			"compileType" : "inject",
			"outputContent" : {"saveas" : "index.html"},
			"imagesProp" : {
				"base64" : true,
				"save_dir" : "",
				"fileProp" : {
					"fileTypeProp" : {
						"png" : {
							"quality" : 95
						},
						"jpeg" : {
							"quality" : 95
						}
					}
				}
			},
			"files" : {
				"data.js" : {"base64" : false}
			},
			"getIncluded" : false,
			"minify" : true
		}
	]
}